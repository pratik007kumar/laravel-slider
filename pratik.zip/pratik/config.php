<?php

$dbhost = "localhost";
$dbname = "pratik_db";
$dbusername = "root";
$dbpassword = "";

$link = new PDO("mysql:host=$dbhost;dbname=$dbname","$dbusername","$dbpassword");

