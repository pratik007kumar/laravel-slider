<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-datepicker.css">
</head>
<body>

<div class="container">
<div class="col-lg-6 col-lg-offset-3">
	<form method="post" action="save.php">
  <div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input type="text" name="name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Name">
    <small id="emailHelp" class="form-text text-muted">Please enter name</small>
  </div>
  <div class="form-group">
    <label for="">Employee ID</label>
    <input type="text" name="emp_id" class="form-control" id="emp_idHelp" placeholder="Emp id">
    <small id="emp_idHelp" class="form-text text-muted">Please Enter Employee ID</small>

  </div>
  <div class="form-group">
    <label for="">Date</label>
    <!-- <input type="text" name="date" class="form-control" id="date" aria-describedby="dateHelp" placeholder="Enter date"> -->

    <div class="input-group date" data-provide="datepicker" aria-describedby="dateHelp" placeholder="Enter date">
    <input type="text" class="form-control" name="date">
    <div class="input-group-addon">
        <span class="glyphicon glyphicon-th"></span>
    </div>
</div>
    <small id="dateHelp" class="form-text text-muted">Please enter Date</small>
  </div>
   
  <div class="form-group">
    <label for="exampleSelect2">Log in Time</label>
  <div class="row">
  <div class="col-lg-2">
    <label for="exampleSelect2">HH</label>

  	<select class="form-control" id="login_hh" name="login_hh">
      <?php for ($i=1; $i <=12 ; $i++) { 
      	echo '<option value="'.$i.'">'.$i.'</option>';
      }
      ?>
    </select>
  </div>  
  <div class="col-lg-2">
    <label for="exampleSelect2">MM</label>

  	<select class="form-control" id="login_mm" name="login_mm">
      <?php for ($i=0; $i <=59 ; $i++) { 
      	echo '<option value="'.$i.'">'.$i.'</option>';
      }
      ?>
    </select>
  </div> 
  </div> 
  </div>
  <div class="form-group">
    <label for="exampleSelect2">Log out Time</label>
  <div class="row">
  <div class="col-lg-2">
    <label for="exampleSelect2">HH</label>

  	<select class="form-control" id="logout_hh" name="logout_hh">
      <?php for ($i=0; $i <=23 ; $i++) { 
      	echo '<option value="'.$i.'">'.$i.'</option>';
      }
      ?>
    </select>
  </div>  
  <div class="col-lg-2">
    <label for="exampleSelect2">MM</label>

  	<select class="form-control" id="logout_mm" name="logout_mm">
      <?php for ($i=0; $i <=59 ; $i++) { 
      	echo '<option value="'.$i.'">'.$i.'</option>';
      }
      ?>
    </select>
  </div> 
  </div> 
  </div>
    
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</div>

<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/bootstrap-datepicker.js"></script>
<script type="text/javascript">
	$(document).ready(function (){
		$('.datepicker').datepicker({
		    format: 'mm/dd/yyyy',
		    startDate: '-3d'
		});
	});

</script>
</body>
</html>