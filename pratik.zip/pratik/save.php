<?php
include 'config.php';
// use DateTime;
// echo '<pre>';
// print_r($_POST);

 $name=$_POST['name'];
 $emp_id=$_POST['emp_id']; 
 $login_hh=$_POST['login_hh']; 
 $login_mm=$_POST['login_mm']; 

 $logout_hh=$_POST['logout_hh']; 
 $logout_mm=$_POST['logout_mm'];  
   
 $date=$_POST['date'];  

$date = str_replace('/', '-', $date);
$attendance_date=date('Y-m-d', strtotime($date));

// Logic							
// 1	Login in right @ 10:30AM or before and logout right @ 19:30 or after will be marked as Present						
// 2	Login in 1 min between 10:31Am to 10:40AM will be marked as 25%						
// 3	Login anytime after 10:45AM will be marked as half day but he have to complete 4hrs of duty since he login, failing to do so will be marked as Absent.						
// 4	Logout 1 min before 19:30 will be marked as Half day provided completing 5hrs of duty						
// 5	Employee has to work atleast 5hrs in a day to get consideration for a Half day starting from 10:30am. Logging out less than 5hrs will be treated as Absent						
$login = new DateTime($login_hh.':'.$login_mm.':00');
$logout = new DateTime($logout_hh.':'.$logout_mm.':00');
 
$office_in_time  = new DateTime('10:30:00');
$office_out_time  = new DateTime('19:30:00');

$office_45_time  = new DateTime('10:45:00');
$office_25_time  = new DateTime('10:40:00');

$diff = $logout->diff($login);


$working_hours = $diff->h;

$status='';

    if ($login  <= $office_in_time && $logout >= $office_out_time ) {
       $status= 'Present';
    }else{
    	//25 %time
    	
		if ($login  <= $office_25_time && $logout >= $office_out_time ) {
		       $status= '25%';
		    }
	
	
	    //if login time is after 10:45 and working hour is less 4hrs
	    elseif($login  > $office_45_time && $working_hours > 4){
	    	$status= 'half day';
	    }
	    //if loout time is berfore 19:30 and working hour is grater then 5hrs
	    elseif($office_out_time > $logout  && $working_hours > 5 ){
		$status= 'half day';	    	
	    }elseif($working_hours < 5){
	    $status= 'Absent';	    	

	    }

 

    }  
 
// // Connect to database db1
 
  $sql="INSERT INTO attendance(name, emp_id, attendance_date,login,logout,status) VALUES('".$name."','". $emp_id."','".$attendance_date."','".$login_hh.':'.$login_mm.':00'."','".$logout_hh.':'.$logout_mm.':00'."','".$status."')";

$statement = $link->prepare($sql);

    $statement->execute();
// print_r($rows);
header('Location: table.php');
 


