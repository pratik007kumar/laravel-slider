<?php
include 'config.php';

 $sql="Select * From attendance";

$statement = $link->prepare($sql);

    $statement->execute();
  $result= $statement->fetchAll();

  ?>

  <!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-datepicker.css">
</head>
<body>

<div class="container" style="padding: 50px">
<div class="row">
	<div class="col-lg-2 ">
		<a href="index.php" class="btn btn-info"> Add New</a>
		<br>
		<br>
	</div>
</div>
	<table class="table table-bodered">
		<thead>
			<tr>
				<th>Name</th>
				<th>Employee ID</th>
				<th>Date</th>
				<th>login Time</th>
				<th>logout Time</th>
				<th>Status</th>
			</tr>
		</thead>
		<tbody>
			
			<?php 
			foreach ($result as $row) {
				echo '<tr>
						<td> '.$row['name'].'</td>
						<td> '.$row['emp_id'].'</td>
						<td> '.date('d-m-Y',strtotime($row['attendance_date'])).'</td>
						<td> '.$row['login'].'</td>
						<td> '.$row['logout'].'</td>
						<td> '.$row['status'].'</td>
					  </tr>';
			}
			?>	
			
		</tbody>
	</table>
</div>
</body>
</html>

